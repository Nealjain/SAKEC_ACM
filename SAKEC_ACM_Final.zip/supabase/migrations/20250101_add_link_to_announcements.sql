ALTER TABLE public.announcements 
ADD COLUMN IF NOT EXISTS link text;
