function Feature() {
  return null;
}

export { Feature };
